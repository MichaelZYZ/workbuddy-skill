"""Small standard-library portability layer; Windows ACLs are not POSIX modes."""
import codecs
import contextlib
import os
from pathlib import Path, PureWindowsPath
import sys

WINDOWS = sys.platform == 'win32'


def configure_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='replace')


def read_text(path):
    data = Path(path).read_bytes()
    if data.startswith((codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE)): return data.decode('utf-32')
    if data.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)): return data.decode('utf-16')
    return data.decode('utf-8-sig')


def private_mode(path, mode):
    if not WINDOWS:
        os.chmod(path, mode)


def default_data_dir():
    if WINDOWS:
        return Path(os.environ.get('LOCALAPPDATA') or Path.home()/'AppData'/'Local')/'diagnose-service'
    return Path.home()/'.local/state/diagnose-service'


def absolute_runtime(value, target_os):
    return PureWindowsPath(value).is_absolute() if target_os == 'windows' else value.startswith('/')


class FileLock:
    """Nonblocking process lock. Close releases the lock on both supported families."""
    def __init__(self, path):
        self.file = open(path, 'a+b')
        try:
            private_mode(path, 0o600)
            if WINDOWS:
                import msvcrt
                self.file.seek(0, 2)
                if self.file.tell() == 0:
                    self.file.write(b'\0'); self.file.flush()
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BaseException:
            self.file.close()
            raise

    def close(self):
        self.file.close()

    def __enter__(self): return self
    def __exit__(self, *args): self.close()


def repair_supported():
    if WINDOWS:
        raise ValueError('Windows原生自动写入和回滚暂未启用：尚未验证NTFS ACL、文件占用与恢复事务。可使用日志诊断、采集、verify和plan；实际修复由维护者执行，或在授权Linux目标机执行。')
