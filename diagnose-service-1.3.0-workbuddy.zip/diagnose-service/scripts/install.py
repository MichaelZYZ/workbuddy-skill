#!/usr/bin/env python3
"""Install a clean local skill copy into an explicitly chosen skills directory."""
import argparse
import platform_support as platform
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]


def install(parent):
    parent = Path(parent).expanduser().absolute()
    target = parent/'diagnose-service'
    if target.exists() or target.is_symlink():
        raise ValueError('目标已存在，请先备份现有技能，再选择空目录；不会覆盖')
    manifest = json.loads((ROOT/'assets/distribution.json').read_text(encoding='utf-8-sig'))
    allowed = manifest['files']
    # Distribute only enumerated release resources, never arbitrary local reports/state.
    for name, expected in allowed.items():
        path = ROOT/name
        if Path(name).is_absolute() or '..' in Path(name).parts or path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(ROOT):
            raise ValueError('发行文件路径无效：'+name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('发行文件哈希不匹配：'+name)
    parent.mkdir(parents=True, exist_ok=True)
    target.mkdir(mode=0o700)
    try:
        for name in list(allowed)+['assets/distribution.json']:
            source, destination = ROOT/name, target/name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
    except BaseException:
        shutil.rmtree(target)
        raise
    print('已安装：'+str(target))
    print('重新加载客户端技能列表；也可在该目录运行 python3 scripts/console.py 打开本地界面。')
    return target


def main():
    platform.configure_stdio()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dest', required=True, help='技能父目录；会在其中创建diagnose-service，不覆盖已有目录')
    a = p.parse_args()
    try: install(a.dest); return 0
    except (ValueError, OSError) as e: print('安装失败：'+str(e)); return 2


if __name__ == '__main__': raise SystemExit(main())
