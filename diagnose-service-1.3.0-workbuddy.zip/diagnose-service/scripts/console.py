#!/usr/bin/env python3
"""Local single-user diagnosis console. No remote commands or outbound requests."""
import argparse
import hmac
import json
import os
from pathlib import Path
import secrets
import sys
import tempfile
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit
import diagnose as core
import platform_support as platform
import time

BASE = Path(__file__).resolve().parents[1]
LANGUAGES = ('auto', 'PHP', 'Python', 'Node.js', 'Java', 'Go')
MAX_BODY = 400000


def clean(value, depth=0):
    if depth > 12:
        return '[nested value truncated]'
    if isinstance(value, str):
        return core.redact(value)
    if isinstance(value, list):
        return [clean(v, depth+1) for v in value]
    if isinstance(value, dict):
        return {k: '[REDACTED]' if k.lower().replace('-', '_') in
                ('password', 'passwd', 'token', 'secret', 'api_key', 'apikey', 'authorization', 'cookie', 'private_key')
                else clean(v, depth+1) for k, v in value.items()}
    return value


def evidence(value):
    if not isinstance(value, dict) or not isinstance(value.get('checks'), list):
        raise ValueError('采集报告必须包含checks数组')
    if not 0 < len(value['checks']) <= 200:
        raise ValueError('报告需要1到200项检查')
    for c in value['checks']:
        if not isinstance(c, dict) or len(json.dumps(c)) > 100000:
            raise ValueError('检查项格式错误或过大，请缩小采集范围')
        for k in ('kind', 'output', 'status', 'observed_at', 'target', 'path'):
            if k in c and not isinstance(c[k], str):
                raise ValueError('检查项的'+k+'必须为文本')
    return clean(value)


def verification(value):
    e = evidence(value)
    if not isinstance(e.get('passed'), bool):
        raise ValueError('验证报告缺少passed布尔值')
    passed = e['passed'] and all(c.get('status') == 'ok' for c in e['checks'])
    business = e.get('business_assertion_present') is True and any(
        c.get('kind') == 'http' and c.get('status') == 'ok' and c.get('assertion') == 'status_and_body'
        for c in e['checks'])
    return {'passed': bool(passed and business), 'checks': e['checks'],
            'business_assertion_present': business, 'imported_at': core.now(),
            'source': '外部导入，需核对来源、目标及时间；不是独立观测'}


def text(b, key, limit=1000):
    v = b.get(key, '')
    if not isinstance(v, str) or len(v) > limit:
        raise ValueError(key+'必须为限定长度的文本')
    return core.redact(v.strip())


class Store:
    def __init__(self, directory):
        self.directory = Path(directory).expanduser().absolute()
        if self.directory.is_symlink():
            raise ValueError('数据目录不能为符号链接')
        self.directory.mkdir(parents=True, mode=0o700, exist_ok=True)
        if not platform.WINDOWS and self.directory.stat().st_uid != os.getuid():
            raise ValueError('数据目录必须属于当前用户')
        platform.private_mode(self.directory, 0o700)
        self.path = self.directory/'state.json'
        if self.path.is_symlink():
            raise ValueError('数据文件不能为符号链接')
        self.lock = platform.FileLock(self.directory/'console.lock')
        try:
            self.state = core.read_json(self.path) if self.path.exists() else {'platforms': [], 'tasks': [], 'events': []}
        except BaseException:
            self.lock.close()
            raise


    def persist(self, state):
        fd, name = tempfile.mkstemp(prefix='.state-', dir=self.directory)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
                f.flush(); os.fsync(f.fileno())
            for attempt in range(4):
                try:
                    os.replace(name, self.path)
                    break
                except PermissionError:
                    if not platform.WINDOWS or attempt == 3: raise
                    time.sleep(.05*(attempt+1))
        finally:
            if os.path.exists(name): os.unlink(name)
        self.state = state

    def action(self, route, b):
        s = json.loads(json.dumps(self.state))
        if route == '/api/platform':
            p = {k: text(b, k) for k in ('name', 'provider', 'environment', 'host', 'timezone', 'runtime', 'log', 'health')}
            if not p['name']: raise ValueError('请填写平台名称')
            p['target_os'] = b.get('target_os', 'windows' if platform.WINDOWS else 'linux')
            if p['target_os'] not in ('linux', 'windows'): raise ValueError('目标系统不支持')
            p['log_encoding'] = text(b, 'log_encoding', 40) or 'utf-8'
            core.codecs.lookup(p['log_encoding'])
            p['language'] = b.get('language', 'auto')
            if p['language'] not in LANGUAGES: raise ValueError('请选择支持的语言')
            p['id'] = str(uuid.uuid4()); s['platforms'].append(p)
            if len(s['platforms']) > 100: raise ValueError('平台上限100，请归档后再创建')
            result = {'id': p['id']}; message = '已保存平台档案；尚未连接服务器'
        elif route == '/api/config':
            p = next((p for p in s['platforms'] if p['id'] == b.get('id')), None)
            if not p: raise ValueError('平台不存在')
            flags = {'PHP': '-v', 'Python': '--version', 'Node.js': '--version', 'Java': '-version', 'Go': 'version'}
            if p['language'] != 'auto' and not platform.absolute_runtime(p['runtime'], p.get('target_os','linux')):
                raise ValueError('导出前请填写实际运行时的绝对路径')
            return {'service': p['name'], 'incident_timezone': p['timezone'] or 'unknown', 'languages': [],
                    'runtime_checks': [[p['runtime'], flags[p['language']]]] if p['language'] != 'auto' else [],
                    'logs': [p['log']] if p['log'] else [], 'tcp': [],
                    'http': [{'url': p['health'], 'status': 200, 'contains': 'REPLACE_WITH_BUSINESS_SUCCESS_MARKER'}] if p['health'] else [],
                    'command_timeout': 8, 'log_encoding': p.get('log_encoding','utf-8'), 'target_os': p.get('target_os','linux')}
        elif route == '/api/diagnose':
            title = text(b, 'title', 120)
            if not title: raise ValueError('请填写故障标题')
            language = b.get('language', 'auto')
            if language not in LANGUAGES: raise ValueError('语言不支持')
            platform_id = b.get('platform', '')
            if platform_id and not any(p['id'] == platform_id for p in s['platforms']): raise ValueError('关联平台不存在')
            if 'evidence' in b:
                e = evidence(b['evidence'])
            else:
                log = text(b, 'log', 262144)
                if not log: raise ValueError('请粘贴日志或导入采集报告')
                e = {'service': title, 'host': '待核对', 'incident_timezone': 'unknown', 'collected_at': core.now(),
                     'checks': [{'kind': 'log', 'historical': True, 'status': 'ok', 'output': log}]}
            d = core.diagnose(e)
            if language != 'auto':
                d['findings'] = [f for f in d['findings'] if f.get('language') in (None, language, 'database', 'network', 'Nginx')]
            t = {'id': str(uuid.uuid4()), 'title': title, 'platform': platform_id, 'language': language,
                 'status': '待核实', 'created_at': core.now(), 'evidence': e, 'diagnosis': d, 'review': '', 'verification': None}
            s['tasks'].insert(0, t)
            if len(s['tasks']) > 200: raise ValueError('任务上限200，请由维护者归档数据目录后再使用')
            result = t; message = '已分析证据；未确认根因，未执行生产变更'
        elif route in ('/api/review', '/api/verification'):
            t = next((t for t in s['tasks'] if t['id'] == b.get('id')), None)
            if not t: raise ValueError('任务不存在')
            if route == '/api/review':
                t['review'] = text(b, 'note', 2000)
                if not t['review']: raise ValueError('请填写审阅说明')
                t['status'] = '已审阅'; message = '已记录审阅；没有执行修复'
            else:
                t['verification'] = verification(b.get('verification'))
                t['status'] = '样本通过' if t['verification']['passed'] else '验证未通过'
                message = '已导入验证记录：'+t['status']+'；仍需核对目标与持续观察'
            result = t
        else:
            raise ValueError('不支持的操作')
        event = {'at': core.now(), 'task': result.get('id') if route != '/api/platform' else None, 'message': message}
        s['events'].insert(0, event); s['events'] = s['events'][:1000]
        self.persist(s)
        print(json.dumps({'event': 'operation', **event}, ensure_ascii=False), file=sys.stderr, flush=True)
        return result


def make_server(store, port=8765):
    token = secrets.token_urlsafe(32)
    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, value, kind='application/json; charset=utf-8'):
            body = json.dumps(value, ensure_ascii=False).encode() if kind.startswith('application/json') else value
            self.send_response(status)
            for k, v in {'Content-Type': kind, 'Content-Length': str(len(body)), 'Cache-Control': 'no-store',
                         'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
                         'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"}.items():
                self.send_header(k, v)
            self.end_headers(); self.wfile.write(body)
        def allowed_host(self):
            return self.headers.get('Host') == '127.0.0.1:'+str(self.server.server_port)
        def do_GET(self):
            if not self.allowed_host(): return self.reply(403, {'error': '仅允许127.0.0.1本地访问'})
            path = urlsplit(self.path).path
            if path == '/api/session': return self.reply(200, {'token': token, 'version': core.VERSION, 'local_os': 'windows' if platform.WINDOWS else 'linux', 'permissions': 'Windows继承当前用户目录ACL；请核对共享目录权限' if platform.WINDOWS else 'POSIX私有目录和文件权限', 'repair': 'linux_only'})
            if path == '/api/state':
                if not hmac.compare_digest(self.headers.get('X-Console-Token', ''), token): return self.reply(403, {'error': '请刷新页面'})
                return self.reply(200, store.state)
            assets = {'/': ('index.html', 'text/html; charset=utf-8'), '/app.js': ('app.js', 'text/javascript; charset=utf-8'), '/style.css': ('style.css', 'text/css; charset=utf-8')}
            if path not in assets: return self.reply(404, {'error': '路径不存在'})
            name, kind = assets[path]
            return self.reply(200, (BASE/'assets/console'/name).read_bytes(), kind)
        def do_POST(self):
            origin = 'http://127.0.0.1:'+str(self.server.server_port)
            if not self.allowed_host() or self.headers.get('Origin') != origin or not hmac.compare_digest(self.headers.get('X-Console-Token', ''), token):
                return self.reply(403, {'error': '请求来源不匹配，请使用启动时显示的本地地址'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if size <= 0 or size > MAX_BODY: return self.reply(413, {'error': '请求需为400KB以内的JSON'})
                b = json.loads(self.rfile.read(size))
                if not isinstance(b, dict): raise ValueError('输入必须是JSON对象')
                return self.reply(200, store.action(urlsplit(self.path).path, b))
            except (ValueError, TypeError, KeyError) as e:
                return self.reply(400, {'error': core.redact(str(e))})
            except Exception:
                return self.reply(500, {'error': '处理或保存失败，未确认保存成功；请检查本地权限和磁盘'})
        def log_message(self, *args):
            pass  # Do not log URL parameters, report content, or the session token.
    server = HTTPServer(('127.0.0.1', port), Handler)
    server.timeout = 5
    return server


def main():
    platform.configure_stdio()
    if sys.version_info < (3,10):
        print('需要Python 3.10或更新版本',file=sys.stderr);return 2
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port', type=int, default=8765)
    p.add_argument('--data-dir', default=str(platform.default_data_dir()))
    args = p.parse_args()
    try:
        store = Store(args.data_dir)
        server = make_server(store, args.port)
        print('诊断台：http://127.0.0.1:'+str(server.server_port)+' （仅本机，Ctrl+C退出）', flush=True)
        print('数据保存在：'+str(store.directory), flush=True)
        if platform.WINDOWS: print('Windows目录沿用用户ACL；请使用自己的非共享目录。原生自动写入/回滚未启用。',flush=True)
        try: server.serve_forever()
        except KeyboardInterrupt: pass
        finally: server.server_close(); store.lock.close()
        return 0
    except Exception as e:
        print('启动失败：'+core.redact(str(e)), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
