"""Bounded pipe capture without selectors; Windows tree cleanup uses taskkill."""
import contextlib
import locale
import os
from pathlib import Path
import queue
import subprocess
import threading
import time


def capture(process, timeout, max_output, terminate):
    """Portable capture algorithm, also exercised against real POSIX subprocesses."""
    q=queue.Queue(maxsize=8); stop=threading.Event()
    def pump():
        try:
            while not stop.is_set():
                chunk=os.read(process.stdout.fileno(),4096)
                while not stop.is_set():
                    try:q.put(chunk,timeout=.05);break
                    except queue.Full:pass
                if not chunk:break
        except (OSError,ValueError):pass
    reader=threading.Thread(target=pump,daemon=True);reader.start()
    start=time.monotonic();data=bytearray();reason=None;eof=False
    try:
        while not eof:
            remaining=timeout-(time.monotonic()-start)
            if remaining<=0:reason='timeout';break
            try:chunk=q.get(timeout=min(.05,remaining))
            except queue.Empty:continue
            if not chunk:eof=True;break
            data.extend(chunk[:max_output-len(data)])
            if len(data)>=max_output:reason='output_limit';break
        if not reason:
            try:process.wait(timeout=max(.01,timeout-(time.monotonic()-start)))
            except subprocess.TimeoutExpired:reason='timeout'
        cleanup=None
        if reason:
            cleanup=terminate(process)
            try:process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill();process.wait(timeout=3)
        return bytes(data),reason,cleanup
    finally:
        stop.set()
        # os.read runs in a daemon thread; no unbounded join/communicate on inherited pipes.
        reader.join(timeout=.1)
        if not reader.is_alive():process.stdout.close()


def terminate_tree(process):
    """Best effort: taskkill cannot prove cleanup of descendants already detached/exited."""
    root=os.environ.get('SystemRoot') or os.environ.get('WINDIR')
    result={'method':'taskkill_T_F','tree_cleanup_confirmed':False}
    if root:
        try:
            with open(os.devnull,'wb') as sink:
                p=subprocess.run([str(Path(root)/'System32'/'taskkill.exe'),'/PID',str(process.pid),'/T','/F'],
                    stdin=subprocess.DEVNULL,stdout=sink,stderr=sink,timeout=3,creationflags=subprocess.CREATE_NO_WINDOW)
            result['exit_code']=p.returncode
        except (OSError,subprocess.TimeoutExpired):result['error']='taskkill unavailable or timed out'
    else:result['error']='SystemRoot unavailable'
    with contextlib.suppress(OSError):process.kill()
    return result


def command(argv, timeout, max_output, redact, now):
    t=time.monotonic();r={'kind':'command','check':Path(argv[0]).name,'observed_at':now()}
    if Path(argv[0]).suffix.lower() in ('.bat','.cmd'):
        return dict(r,status='unavailable',detail='Windows batch files are not executed; configure the actual .exe and argv, without a shell')
    allowed={'PATH','LANG','LC_ALL','TZ','SystemRoot','WINDIR','COMSPEC','PATHEXT','TEMP','TMP'}
    env={k:v for k,v in os.environ.items() if k.upper() in {x.upper() for x in allowed}}
    try:
        p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,
                           env=env,bufsize=0,creationflags=subprocess.CREATE_NO_WINDOW)
    except FileNotFoundError:return dict(r,status='unavailable',detail='executable not found')
    except PermissionError:return dict(r,status='permission_denied')
    except OSError as e:return dict(r,status='unavailable',detail=redact(str(e)))
    data,reason,cleanup=capture(p,timeout,max_output,terminate_tree)
    result=dict(r,status=reason or ('ok' if p.returncode==0 else 'failed'),exit_code=p.returncode,
                duration_ms=round((time.monotonic()-t)*1000),output=redact(data.decode(locale.getpreferredencoding(False),errors='replace')))
    if cleanup:result['cleanup']=cleanup
    return result
