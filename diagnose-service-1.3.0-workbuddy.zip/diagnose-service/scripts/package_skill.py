#!/usr/bin/env python3
"""Build a clean, deterministic distribution ZIP from the checked release inventory."""
import argparse
import platform_support as platform
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def build(output, target='generic', author=None):
    m = json.loads((ROOT/'assets/distribution.json').read_text(encoding='utf-8-sig'))
    files = {}
    for name, expected in m['files'].items():
        p=ROOT/name
        if Path(name).is_absolute() or '..' in Path(name).parts or p.is_symlink() or not p.resolve().is_relative_to(ROOT):
            raise ValueError('Invalid release path: '+name)
        data=p.read_bytes()
        if hashlib.sha256(data).hexdigest()!=expected:
            raise ValueError('Release file hash mismatch: '+name)
        files[name]=data
    if target=='workbuddy':
        if not author or len(author)>100 or '\n' in author:
            raise ValueError('WorkBuddy requires --author (maintainer or project display name)')
        skill=files['SKILL.md'].decode()
        match=re.match(r'---\n(.*?)\n---\n',skill,re.S)
        if not match:raise ValueError('Invalid SKILL.md frontmatter')
        fields={'name':'diagnose-service','display_name':'多语言故障诊断与修复验证',
                'description':'Diagnose service failures using evidence, review minimal repairs, and verify recovery.',
                'description_zh':'分析PHP、Python、Node.js、Java、Go与基础设施故障日志，生成可验证的修复方案。',
                'description_en':'Evidence-based triage for PHP, Python, Node.js, Java, Go, Nginx, TCP, and database errors.',
                'version':m['version'],'author':author}
        header='---\n'+'\n'.join(k+': '+json.dumps(v,ensure_ascii=False) for k,v in fields.items())+'\n---\n'
        note='\n## WorkBuddy运行入口\n\n先读 @references/workbuddy.md。先检查Python 3.10+及本机系统。Windows 10/11已加入原生诊断和本地界面适配，但实机验收待完成，自动写入/回滚仍限Linux。实际修复在已授权目标环境执行。需要操作界面时按 @references/console-guide.md 启动本机界面；导入技能不会自动打开网页或安装依赖。\n'
        files['SKILL.md']=(header+note+skill[match.end():]).encode()
        files.pop('agents/openai.yaml',None)
    elif target!='generic':raise ValueError('Unknown target')
    # Variant hashes must describe the transformed package, not the source header.
    m['target']=target
    m['files']={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
    files['assets/distribution.json']=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode()
    output=Path(output).expanduser().absolute()
    if output.exists():raise ValueError('Output already exists; choose a new path')
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(files.items()):
            info=zipfile.ZipInfo('diagnose-service/'+name,date_time=(2026,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16
            z.writestr(info,data)
    return {'path':str(output),'target':target,'version':m['version'],'files':len(files),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}


def main():
    platform.configure_stdio()
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target',choices=('generic','workbuddy'),default='generic')
    p.add_argument('--author')
    p.add_argument('--out',required=True)
    a=p.parse_args()
    try: print(json.dumps(build(a.out,a.target,a.author),ensure_ascii=False));return 0
    except (ValueError,OSError) as e: print(str(e));return 2


if __name__=='__main__':raise SystemExit(main())
