#!/usr/bin/env python3
"""Real local HTTP public-release checks; no credentials or production targets."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import urllib.request
import urllib.error

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE/'scripts'))
import console as app


def main():
    checks = []
    def ok(name, value):
        if not value: raise AssertionError(name)
        checks.append(name); print('PASS', name)
    with tempfile.TemporaryDirectory(prefix='console-release-') as temp:
        store = app.Store(Path(temp)/'state')
        server = app.make_server(store, 0)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        origin = f'http://127.0.0.1:{server.server_port}'
        def req(path, body=None, headers=None):
            data = json.dumps(body).encode() if body is not None else None
            h = {'Content-Type':'application/json', **(headers or {})}
            try:
                with urllib.request.urlopen(urllib.request.Request(origin+path, data=data, headers=h), timeout=3) as r:
                    raw = r.read(); return r.status, json.loads(raw) if r.headers['Content-Type'].startswith('application/json') else raw, r.headers
            except urllib.error.HTTPError as e: return e.code, json.loads(e.read()), e.headers
        try:
            status, _, headers = req('/')
            ok('offline-assets-and-csp', status==200 and "script-src 'self'" in headers['Content-Security-Policy'])
            ok('script-served-locally',req('/app.js')[0]==200)
            ok('style-served-locally',req('/style.css')[0]==200)
            ok('state-requires-token',req('/api/state')[0]==403)
            token = req('/api/session')[1]['token']
            h = {'X-Console-Token':token,'Origin':origin}
            ok('cross-origin-rejected',req('/api/platform',{},dict(h,Origin='https://example.org'))[0]==403)
            ok('missing-token-rejected',req('/api/platform',{}, {'Origin':origin})[0]==403)
            ok('host-rebinding-rejected',req('/api/session',headers={'Host':'attacker.example'})[0]==403)
            ok('path-traversal-rejected',req('/../../scripts/diagnose.py')[0]==404)
            p = {'name':'Example Python','provider':'Docker','environment':'测试','language':'Python','runtime':'/usr/bin/python3','timezone':'UTC','log':'/var/log/example.log'}
            status, platform, _ = req('/api/platform', p, h)
            ok('platform-persistence',status==200 and len(store.state['platforms'])==1)
            cfg = req('/api/config',{'id':platform['id']},h)[1]
            ok('export-config-no-execution',cfg['runtime_checks']==[['/usr/bin/python3','--version']] and cfg['logs']==['/var/log/example.log'])
            body = {'title':'Example incident','language':'Python','platform':platform['id'],'log':"ModuleNotFoundError: requests token=secret_fixture"}
            status, task, _ = req('/api/diagnose',body,h)
            ok('diagnose-with-evidence',status==200 and task['diagnosis']['findings'][0]['rule']=='python_import')
            ok('root-cause-remains-unconfirmed',task['diagnosis']['expert_review']['root_cause_confirmed'] is False)
            ok('credentials-not-persisted','secret_fixture' not in store.path.read_text())
            status,t,_=req('/api/review',{'id':task['id'],'note':'Check interpreter and venv before any change'},h)
            ok('review-is-record-only',status==200 and t['status']=='已审阅' and t['review'])
            v={'passed':True,'business_assertion_present':True,'checks':[{'kind':'http','status':'failed','assertion':'status_and_body'}]}
            t=req('/api/verification',{'id':task['id'],'verification':v},h)[1]
            ok('claimed-success-with-failed-check-rejected',t['status']=='验证未通过')
            v['checks'][0].update(status='ok',assertion='status_only')
            t=req('/api/verification',{'id':task['id'],'verification':v},h)[1]
            ok('http200-alone-not-business-recovery',t['status']=='验证未通过')
            v['checks'][0]['assertion']='status_and_body'
            t=req('/api/verification',{'id':task['id'],'verification':v},h)[1]
            ok('valid-import-is-only-sample-passed',t['status']=='样本通过' and '外部导入' in t['verification']['source'])
            ok('malformed-evidence-rejected',req('/api/diagnose',{'title':'x','evidence':{'checks':[{'output':{}}]}},h)[0]==400)
            out=req('/api/state',headers=h)[1]
            ok('events-actually-recorded',len(out['events'])>=5 and out['tasks'][0]['id']==task['id'])
            ok('private-file-permissions' if not app.platform.WINDOWS else 'windows-acl-model-disclosed', (os.stat(store.path).st_mode&0o777==0o600 and os.stat(store.directory).st_mode&0o777==0o700) if not app.platform.WINDOWS else 'Windows' in req('/api/session')[1]['permissions'])
            ok('nested-secret-redaction',app.clean({'nested':{'token':'sensitive'}})['nested']['token']=='[REDACTED]')
            ok('unknown-language-rejected',req('/api/diagnose',{'title':'x','language':'unknown','log':'test'},h)[0]==400)
            ok('oversized-request-rejected',req('/api/diagnose',{'log':'x'*400001},h)[0]==413)
        finally:
            server.shutdown();server.server_close();thread.join();store.lock.close()
        reopened=app.Store(Path(temp)/'state')
        ok('restart-retains-user-data',len(reopened.state['tasks'])==1 and len(reopened.state['events'])>=5)
        reopened.lock.close()
    print(json.dumps({'passed':len(checks),'failed':0,'scope':'localhost HTTP and state integration, not production or multiuser authentication'},ensure_ascii=False))


if __name__=='__main__': main()
