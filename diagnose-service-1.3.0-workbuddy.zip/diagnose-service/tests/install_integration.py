#!/usr/bin/env python3
"""Validate clean offline installation and contamination/tamper rejection."""
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import sys

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'scripts'))
spec=importlib.util.spec_from_file_location('release_install',BASE/'scripts/install.py')
i=importlib.util.module_from_spec(spec);spec.loader.exec_module(i)


def main():
    passed=0
    def check(name,condition):
        nonlocal passed
        if not condition:raise AssertionError(name)
        passed+=1;print('PASS',name)
    with tempfile.TemporaryDirectory(prefix='release-install-') as temp:
        root=Path(temp);source=root/'source';source.mkdir()
        manifest=json.loads((BASE/'assets/distribution.json').read_text())
        for name in list(manifest['files'])+['assets/distribution.json']:
            p=source/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(BASE/name,p)
        i.ROOT=source
        (source/'evidence.json').write_text('{"private":"fixture"}')
        (source/'runtime').mkdir();(source/'runtime/state.json').write_text('{"private":"fixture"}')
        (source/'secret.key').write_text('SYNTHETIC TEST ONLY')
        installed=i.install(root/'skills')
        check('clean-skill-layout',(installed/'SKILL.md').is_file() and (installed/'assets/console/app.js').is_file())
        check('unlisted-runtime-data-excluded',not any((installed/p).exists() for p in ['evidence.json','runtime','secret.key']))
        check('exact-manifest-files',{str(p.relative_to(installed)) for p in installed.rglob('*') if p.is_file()}==set(manifest['files'])|{'assets/distribution.json'})
        try:i.install(root/'skills');raise AssertionError('overwritten existing skill')
        except ValueError:check('existing-install-not-overwritten',True)
        (source/'scripts/diagnose.py').write_text('# altered fixture\n')
        try:i.install(root/'tampered');raise AssertionError('accepted altered release')
        except ValueError:check('tampered-source-rejected',not (root/'tampered/diagnose-service').exists())
    print(json.dumps({'passed':passed,'failed':0}))


if __name__=='__main__':main()
