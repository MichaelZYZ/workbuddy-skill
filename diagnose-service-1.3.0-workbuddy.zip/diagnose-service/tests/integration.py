#!/usr/bin/env python3
"""Real localhost fixtures; no production targets. Optional runtimes are reported as skipped."""
import contextlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'scripts'))
spec = importlib.util.spec_from_file_location('diagnose', BASE/'scripts/diagnose.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
RESULTS = []


def record(name, fn):
    try:
        detail = fn()
        RESULTS.append({'name': name, 'status': 'passed', 'detail': detail})
        print('PASS', name, flush=True)
    except Exception as e:
        RESULTS.append({'name': name, 'status': 'failed', 'detail': str(e)})
        print('FAIL', name, str(e), flush=True)


def require(value, message='assertion failed'):
    if not value:
        raise AssertionError(message)


def makeplan(root, target, before, after, validation):
    from argparse import Namespace
    obj = d.make_plan(Namespace(service='fixture', root=str(root), target=str(target),
                               before=before, after=after, validation=str(validation)))
    p = root/('plan-'+str(len(list(root.glob('plan-*'))))+'.json')
    d.save(p, obj)
    return p


def main():
    with tempfile.TemporaryDirectory(prefix='diagnose-integration-') as temp:
        root = Path(temp)
        state = root/'health.txt'
        state.write_text('READY')
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                body = state.read_bytes() if state.exists() else b'NOT_READY'
                self.send_response(200)
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, *args):
                pass
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f'http://127.0.0.1:{server.server_port}/health'
        py = sys.executable
        runtimes = {k: shutil.which(v[0]) for k, v in d.LANGS.items()}
        def tcp_test():
            sock = socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            # Bound but not listening, port cannot race with another listener.
            try:
                r = d.tcp('127.0.0.1', port)
                require(r['status']=='refused', str(r))
                diag = d.diagnose({'checks':[r]})
                require(diag['findings'][0]['rule']=='tcp_refused')
            finally:
                sock.close()
            require(d.tcp('127.0.0.1', server.server_port)['status']=='ok')
            return 'real TCP refusal and healthy listener distinguished'
        record('tcp-refused-and-success', tcp_test)
        def http_test():
            require(d.http_probe({'url':url,'contains':'READY'})['status']=='ok')
            require(d.http_probe({'url':url,'contains':'ABSENT'})['status']=='failed')
            return 'HTTP200 with wrong body rejected'
        record('business-body-verification', http_test)
        def missing():
            require(d.command(['/definitely/missing/tool'])['status']=='unavailable')
            require(d.tail(root/'absent.log')['status']=='unavailable')
            require(not d.diagnose({'checks':[{'status':'unavailable'}]})['findings'])
            return 'missing tools/logs are evidence gaps, not root causes'
        record('missing-evidence', missing)
        def redaction():
            data='password=hello token=secret123 Authorization: Bearer abc Cookie: session=xyz https://u:pass@host/'
            out=d.redact(data)
            for value in ('hello','secret123','abc','xyz','u:pass'):
                require(value not in out, out)
            return 'common credentials redacted'
        record('credential-redaction', redaction)
        def bounds():
            require(d.command([py,'-c','import time; time.sleep(5)'],.15)['status']=='timeout')
            r=d.command([py,'-c','print("x"*100000)'])
            require(r['status']=='output_limit' and len(r['output'])<=d.MAX_OUTPUT)
            r=d.command([py,'-c','import os,time;os.close(1);os.close(2);time.sleep(5)'],.15)
            require(r['status']=='timeout',str(r))
            return 'bounded wall time, output and closed-stdout hanging process'
        record('collector-resource-bounds', bounds)
        def phase_failfast():
            marker=root/'should-not-exist'
            results,ok=d.phase({'activate':[[py,'-c','raise SystemExit(1)'],[py,'-c','from pathlib import Path;Path('+repr(str(marker))+').touch()']]},'activate')
            require(not ok and len(results)==1 and not marker.exists())
            return 'dependent actions stop after first failed command'
        record('phase-failure-stops-dependent-actions',phase_failfast)
        def config_tests():
            target=root/'config.json';target.write_text('{"mode":"OLD"}')
            m=root/'validation.json'
            d.save(m, {'preflight':[[py,'-c','import json,sys;json.load(open(sys.argv[1]))',str(target)]],
                       'http':[{'url':url,'contains':'READY'}], 'samples':2,'interval':0})
            plan=makeplan(root,target,'OLD','NEW',m)
            r=d.apply(plan,root/'history');require(r['status']=='verified_sample',str(r))
            require('NEW' in target.read_text())
            r=d.apply(plan,root/'history',True,r['journal']);require(r['status']=='rolled_back',str(r))
            require('OLD' in target.read_text())
            require((os.stat(root/'history').st_mode & 0o777)==0o700)
            # Preflight failure must restore old file and never activate invalid data.
            bad=makeplan(root,target,'"OLD"','BROKEN',m)
            r=d.apply(bad,root/'history');require(r['status']=='restored',str(r))
            require(target.read_text()=='{"mode":"OLD"}')
            # Verification failure (syntax valid) must also restore.
            d.save(m, {'preflight':[[py,'-c','pass']], 'http':[{'url':url,'contains':'NOPE'}], 'samples':1,'interval':0})
            bad=makeplan(root,target,'OLD','NEW',m)
            r=d.apply(bad,root/'history');require(r['status']=='restored_unhealthy',str(r))
            require(not d.read_json(r['journal'])['restore_verification']['passed'])
            # Concurrent edit since plan creation is rejected without overwriting it.
            target.write_text('{"mode":"OTHER"}')
            try:
                d.apply(bad,root/'history')
                raise AssertionError('concurrent edit accepted')
            except ValueError:
                pass
            require('OTHER' in target.read_text())
            # Symlink escape rejected at planning time.
            link=root/'link';link.symlink_to(target)
            try:
                makeplan(root,link,'OTHER','NEW',m)
                raise AssertionError('symlink accepted')
            except ValueError:
                pass
            return 'apply/explicit rollback/preflight failure/probe failure/hash conflict/symlink rejection'
        record('transaction-and-rollback',config_tests)
        def missing_business_assertion():
            f=root/'noassert.conf';f.write_text('before')
            m=root/'noassert.json';d.save(m,{'preflight':[[py,'-c','pass']], 'http':[{'url':url}]})
            plan=makeplan(root,f,'before','after',m)
            try:
                d.apply(plan,root/'history')
                raise AssertionError('status-only repair validation accepted')
            except ValueError:
                pass
            require(f.read_text()=='before')
            return 'repair requires nonempty business body assertion'
        record('reject-status-only-repair',missing_business_assertion)
        # Real language failures and one-line fixes through the same transaction engine.
        cases=[]
        php=runtimes['php']
        if php:
            path=root/'test.php'
            src='<?php require __DIR__."/missing.php"; file_put_contents('+json.dumps(str(state))+', "READY");'
            cases.append(('php',path,src,'missing.php','present.php',[php,str(path)],
                          [php,'-n','-l',str(path)],'php_dependency'))
            (root/'present.php').write_text('<?php // fixture dependency\n')
            path=root/'implode.php'
            src='<?php $arr=["a","b"]; $key=implode($arr, "_"); file_put_contents('+json.dumps(str(state))+', $key === "a_b" ? "READY" : "WRONG");'
            cases.append(('php-implode',path,src,'implode($arr, "_")','implode("_", $arr)',[php,str(path)], [php,'-n','-l',str(path)],'php_argument_type'))
        node=runtimes['node']
        if node:
            path=root/'test.cjs'
            src='require("./missing.cjs"); require("fs").writeFileSync('+json.dumps(str(state))+',"READY");'
            cases.append(('node',path,src,'missing.cjs','present.cjs',[node,str(path)],
                          [node,'--check',str(path)],'node_module'))
            (root/'present.cjs').write_text('module.exports = {};')
        path=root/'test.py'
        src='import missing_fixture\nfrom pathlib import Path\nPath('+repr(str(state))+').write_text("READY")\n'
        (root/'present_fixture.py').write_text('value=1\n')
        cases.append(('python',path,src,'missing_fixture','present_fixture',[py,str(path)],
                      [py,'-c','import sys; compile(open(sys.argv[1]).read(),sys.argv[1],"exec")',str(path)],'python_import'))
        java=runtimes['java']
        if java:
            path=root/'Main.java'
            src='import java.nio.file.*; class Main { public static void main(String[] a) throws Exception { Class.forName("MissingFixture"); Files.writeString(Path.of('+json.dumps(str(state))+'),"READY"); } }'
            # Source launcher requires jdk.compiler; missing compiler is a failed runtime check, not simulated.
            cases.append(('java',path,src,'MissingFixture','java.lang.String',[java,str(path)],
                          [java,'com.sun.tools.javac.Main','-d',str(root),str(path)],'java_dependency'))
        go=runtimes['go']
        if go:
            path=root/'main.go'
            src='package main\nimport "os"\nfunc main(){ var p *int; _ = *p; os.WriteFile('+json.dumps(str(state))+', []byte("READY"),0600) }\n'
            goenv=['/usr/bin/env','GOTOOLCHAIN=local','GO111MODULE=off','GOCACHE='+str(root/'gocache')]
            cases.append(('go',path,src,'var p *int','v := 1; p := &v',goenv+[go,'run',str(path)],
                          goenv+[go,'build','-o',str(root/'go-fixture'),str(path)],'go_panic'))
        for lang,path,src,before,after,run,syntax,rule in cases:
            def run_case(lang=lang,path=path,src=src,before=before,after=after,run=run,syntax=syntax,rule=rule):
                state.write_text('NOT_READY')
                path.write_text(src)
                failure=d.command(run,60)
                require(failure['status']=='failed',str(failure))
                # PHP require missing is a dependency failure, not an undefined-function signature.
                diag=d.diagnose({'checks':[failure]})
                require(any(f['rule']==rule for f in diag['findings']),str(diag))
                val=root/('validate-'+lang+'.json')
                d.save(val, {'preflight':[syntax], 'activate':[run],
                             'http':[{'url':url,'contains':'READY'}], 'samples':2,'interval':0})
                plan=makeplan(root,path,before,after,val)
                result=d.apply(plan,root/'history')
                require(result['status']=='verified_sample',str(result))
                require(state.read_text()=='READY')
                return {'failure_exit':failure['exit_code'], 'repaired':True,
                        'business_probe':result['verification']['passed'], 'runtime':run[0]}
            record('real-'+lang+'-diagnose-repair-verify',run_case)
        for lang in d.LANGS:
            if not runtimes[lang]:
                RESULTS.append({'name':'real-'+lang,'status':'skipped','detail':'runtime not installed'})
        def collect_test():
            log=root/'app.log';log.write_text('token=secret_value\nModuleNotFoundError: no such module\n')
            m=root/'environment.json'
            d.save(m,{'service':'local-fixture','languages':['python'], 'logs':[str(log)],'http':[{'url':url,'contains':'READY'}]})
            out=root/'collected.json'
            r=d.command([py,str(BASE/'scripts/diagnose.py'),'collect',str(m),'--out',str(out)],15)
            require(r['status']=='ok',str(r))
            ev=d.read_json(out);require('secret_value' not in out.read_text())
            require(any(c['kind']=='log' and c['historical'] for c in ev['checks']))
            diagnosis=root/'diagnosis.json'
            r=d.command([py,str(BASE/'scripts/diagnose.py'),'diagnose',str(out),'--out',str(diagnosis)])
            require(r['status']=='ok' and any(f['rule']=='python_import' for f in d.read_json(diagnosis)['findings']))
            return 'real collector and diagnostic CLI with redacted log and live localhost probe'
        record('collect-and-diagnose-cli',collect_test)
        # Historical signatures never attributed to live services.
        def replay():
            logs=[('php_missing_extension',"PHP Startup: Unable to load dynamic library 'redis.so'"),
                  ('php_slow_downstream','[stack] curl_exec() HttpHelper.php'),
                  ('php_memory_limit','Allowed memory size of 16777216 bytes exhausted'),
                  ('db_unique_conflict','psycopg2.errors.UniqueViolation duplicate key value violates unique constraint'),
                  ('pg_client_disconnect','unexpected EOF on client connection with an open transaction'),
                  ('java_heap','java.lang.OutOfMemoryError: Java heap space')]
            for rule,log in logs:
                r=d.diagnose({'checks':[{'kind':'log','status':'ok','historical':True,'output':log}]})
                require(any(f['rule']==rule for f in r['findings']),rule)
            r=d.diagnose({'checks':[{'output':'checkpoint complete: write=269.9 s, sync=0.004 s'}]})
            require(not r['findings'],'checkpoint falsely diagnosed')
            return '6 historical signatures + checkpoint false-positive guard'
        record('historical-log-replay',replay)
        def expert_review():
            e={'service':'fixture','host':'test-host','collected_at':d.now(),'incident_timezone':'UTC',
               'checks':[{'kind':'log','status':'ok','historical':True,'output':'Connection refused'},
                         {'kind':'tcp','status':'ok'}, {'kind':'log','status':'permission_denied'}]}
            r=d.diagnose(e)
            f=next(f for f in r['findings'] if f['rule']=='tcp_refused_log')
            require(f['evidence_scope'][0]['historical'] is True)
            require(f['decision']['state']=='needs_discriminating_evidence')
            require(r['expert_review']['successful_probe_indices']==[1])
            require(r['expert_review']['change_ready'] is False and not r['expert_review']['missing_context'])
            require(r['evidence_gaps']==[2])
            require(len(d.diagnose({'checks':[]})['expert_review']['missing_context'])==3)
            return 'historical refusal + live TCP success retains uncertainty, provenance and action gates'
        record('expert-evidence-and-decision-gates',expert_review)

        server.shutdown();server.server_close();thread.join()
    result={'schema_version':1,'ran_at':d.now(),'results':RESULTS,
            'counts':{s:sum(r['status']==s for r in RESULTS) for s in ('passed','failed','skipped')},
            'limits':['Local isolated fixtures; no production validation.',
                      'Runtime tests validate diagnostic/repair mechanics, not exhaustive framework compatibility.']}
    if len(sys.argv)>1:
        d.save(sys.argv[1],result)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 1 if result['counts']['failed'] else 0


if __name__=='__main__':
    sys.exit(main())
