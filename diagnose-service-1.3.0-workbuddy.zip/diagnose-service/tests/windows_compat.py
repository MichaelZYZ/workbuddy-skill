#!/usr/bin/env python3
"""Native Windows acceptance when run there; branch simulations on other systems."""
import codecs
import contextlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import platform as host_platform
import types
from unittest.mock import patch

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'scripts'))
import platform_support as platform
import diagnose as core
import console as app
from windows_command import capture


def main():
    real_windows=sys.platform=='win32';results=[]
    def test(name,fn,scope='portable_real'):
        fn();results.append({'name':name,'passed':True,'scope':scope});print('PASS',name,scope)
    def check(v):
        if not v:raise AssertionError('assertion failed')
    with tempfile.TemporaryDirectory(prefix='diagnose-兼容-') as temp:
        root=Path(temp)
        def unicode_json():
            p=root/'中文 空格.json';core.save(p,{'服务':'订单'});check(core.read_json(p)['服务']=='订单')
            p.write_bytes(codecs.BOM_UTF8+json.dumps({'服务':'订单'},ensure_ascii=False).encode());check(core.read_json(p)['服务']=='订单')
            p.write_bytes(json.dumps({'服务':'订单'},ensure_ascii=False).encode('utf-16'));check(core.read_json(p)['服务']=='订单')
        test('utf8-and-bom-json-paths',unicode_json)
        def logs():
            value='ModuleNotFoundError: 示例模块\r\n'
            for enc in ['utf-8-sig','utf-16','gb18030']:
                p=root/(enc+'.log');p.write_bytes(value.encode(enc));r=core.tail(p,encoding=enc);check('示例模块' in r['output'])
            p=root/'large-utf16.log';p.write_bytes(('prefix\r\n'*20000+value).encode('utf-16'));check('示例模块' in core.tail(p)['output'])
        test('utf8-utf16-gbk-crlf-logs',logs)
        def paths():
            check(platform.absolute_runtime('C:\\Program Files\\Python\\python.exe','windows'))
            check(platform.absolute_runtime('\\\\server\\share\\python.exe','windows'))
            check(not platform.absolute_runtime('C:python.exe','windows'))
            check(not platform.absolute_runtime('python.exe','windows'))
        test('windows-absolute-path-semantics',paths)
        def wrong_host():
            m=root/'wrong-host.json';core.save(m,{'service':'fixture','target_os':'linux' if real_windows else 'windows'})
            try:core.collect(m);raise AssertionError('cross-OS collection accepted')
            except ValueError as e:check('目标系统' in str(e))
        test('wrong-target-os-refused-before-collection',wrong_host)

        def cap(code,timeout=.3,limit=32768):
            p=subprocess.Popen([sys.executable,'-c',code],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,bufsize=0)
            return capture(p,timeout,limit,lambda proc:(proc.kill() or {'test_cleanup':'direct_fixture_process'}))
        test('pipe-capture-success',lambda:check(b'hello' in cap('print("hello")')[0]))
        test('pipe-capture-output-bound',lambda:check(cap('print("x"*100000)')[1]=='output_limit'))
        test('pipe-capture-timeout',lambda:check(cap('import time;time.sleep(5)')[1]=='timeout'))
        test('closed-stdout-still-bounded',lambda:check(cap('import os,time;os.close(1);os.close(2);time.sleep(5)')[1]=='timeout'))
        def simulated_windows():
            calls=[];fake=types.SimpleNamespace(LK_NBLCK=2,locking=lambda fd,mode,count:calls.append((mode,count)))
            with patch.object(platform,'WINDOWS',True),patch.dict(sys.modules,{'msvcrt':fake}),patch.dict(os.environ,{'LOCALAPPDATA':str(root/'本机用户')}):
                check('diagnose-service'==platform.default_data_dir().name)
                store=app.Store(root/'windows-state')
                try:
                    p=store.action('/api/platform',{'name':'演示','language':'Python','target_os':'windows','runtime':'C:\\Program Files\\Python\\python.exe','log':'C:\\日志\\应用.log','log_encoding':'gb18030'})
                    cfg=store.action('/api/config',{'id':p['id']});check(cfg['runtime_checks'][0][0].startswith('C:'));check(cfg['log_encoding']=='gb18030')
                    t=store.action('/api/diagnose',{'title':'示例','language':'Python','log':'ModuleNotFoundError: 示例'})
                    check(t['diagnosis']['findings'][0]['rule']=='python_import')
                    real_replace=os.replace;count=[0]
                    def flaky(a,b):
                        count[0]+=1
                        if count[0]<3:raise PermissionError('simulated antivirus hold')
                        return real_replace(a,b)
                    with patch.object(os,'replace',side_effect=flaky):store.persist(store.state)
                    check(count[0]==3)
                    before=store.path.read_bytes()
                    with patch.object(os,'replace',side_effect=PermissionError('held')):
                        try:store.persist({'bad':'new state'});raise AssertionError('accepted locked file')
                        except PermissionError:pass
                    check(store.path.read_bytes()==before and store.state['tasks'][0]['id']==t['id'])
                    try:core.apply(root/'absent-plan',root/'must-not-exist');raise AssertionError('Windows mutation permitted')
                    except ValueError as e:check('Windows' in str(e))
                    check(not (root/'must-not-exist').exists())
                finally:store.lock.close()
                check(calls and all(c==(2,1) for c in calls))
        if not real_windows:test('windows-lock-store-config-and-replace-branches',simulated_windows,'simulated_windows_not_native')
        def lock_test():
            p=root/'real-lock'
            with platform.FileLock(p):
                try:
                    with platform.FileLock(p):raise AssertionError('second lock acquired')
                except OSError:pass
            with platform.FileLock(p):pass
        test('exclusive-lock-release',lock_test,'native_windows' if real_windows else 'native_posix')
        if real_windows:
            def native_command():
                r=core.command([sys.executable,'-c','print("windows native smoke")']);check(r['status']=='ok')
                check(core.command([sys.executable,'-c','import time;time.sleep(5)'],.2)['status']=='timeout')
                check(core.command(['unavailable-fixture-executable.exe'])['status']=='unavailable')
                check(core.command(['unsafe-fixture.cmd'])['status']=='unavailable')
            test('windows-native-spawn-and-cleanup',native_command,'native_windows')
            def native_state():
                s=app.Store(root/'native-state')
                try:s.action('/api/diagnose',{'title':'原生Windows','log':'ModuleNotFoundError: fixture'})
                finally:s.lock.close()
                s=app.Store(root/'native-state')
                try:check(len(s.state['tasks'])==1)
                finally:s.lock.close()
            test('windows-native-state-reopen',native_state,'native_windows')
    result={'ran_at':core.now(),'actual_system':sys.platform,'os_release':host_platform.release(),'os_version':host_platform.version(),'architecture':host_platform.machine(),'windows_native_verified':real_windows,'results':results,
            'passed':len(results),'failed':0,'limits':['Windows 10/11 OS builds must be run separately; Linux branch simulations do not certify either OS.','NTFS ACL and native Windows repair/rollback not enabled.']}
    if len(sys.argv)>1:core.save(sys.argv[1],result)
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
