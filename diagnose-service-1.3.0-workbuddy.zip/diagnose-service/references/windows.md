# Windows 10 / 11 适配说明 · 1.3.0

## 支持口径

已按Windows API差异加入原生适配：模块导入、日志分析、本地界面、平台配置、日志/JSON导入、UTF-8/BOM与可选GB18030日志、UTF-16日志、只读采集、HTTP/TCP验证及plan。

这代表“已实现适配，待真实Windows验收”，不是“已在Windows 10和11分别验证通过”。当前测试主机为Linux；分支模拟不能验证msvcrt真实文件锁、杀毒软件占用、Windows Python安装、浏览器或WorkBuddy执行工具联动。

| 功能 | Windows适配状态 | 验收边界 |
|---|---|---|
| 对话日志分析 | 可用能力不依赖本机Unix模块 | WorkBuddy客户端实际导入/触发待测 |
| 本地界面及数据保存 | 已加入跨平台锁、UTF-8保存与占用重试 | 原生msvcrt/NTFS/浏览器待测 |
| 路径配置 | 支持盘符绝对路径、空格、中文和UNC语义 | 不自动验证远端路径存在 |
| 日志读取 | UTF-8、BOM UTF-16/32、显式GB18030等 | 无BOM编码需操作者选择，不猜测全部格式 |
| collect与verify | Windows命令分支、线程读取管道、显式目标探测 | 原生进程树清理仍需实测；taskkill为尽力而为 |
| plan | 可生成精确修改计划，不写目标文件 | 计划中的绝对路径属于生成它的目标机 |
| apply与rollback | Windows明确拒绝，且在写入工作目录前拒绝 | NTFS ACL、文件占用、事务恢复未完成适配验收；Linux功能保留 |

## 启动

安装Python 3.10+，在实际技能目录打开PowerShell：

```powershell
py -3 --version
py -3 -X utf8 .\scripts\console.py
```

也可双击技能根目录launch-console.cmd；它仅选择Python解释器并启动本机界面，不安装软件、不提权、不修改生产。若py未安装，可用实际python.exe或python命令。

浏览器打开终端显示的 http://127.0.0.1:8765 。端口占用时：

```powershell
py -3 -X utf8 .\scripts\console.py --port 8766
```

不要绕过系统安全警告、修改全局PowerShell执行策略或将单用户界面暴露公网。普通账号即可；不要求管理员权限。

## 数据与权限

默认目录：当前用户%LOCALAPPDATA%\diagnose-service；缺少该环境变量时使用用户主目录下AppData\Local\diagnose-service。

Windows沿用所选目录的NTFS ACL，不以chmod(0600/0700)冒充ACL隔离，也不自动重写现有目录权限。使用自己账户的非共享目录；自定义到共享盘前核对访问权限。记录原子替换遇到PermissionError会有限重试，仍失败时明确报错、保留原状态，不宣称保存成功。

## 配置目标系统

本机是Windows、目标服务器是Linux时，平台档案选Linux，填远端实际Unix路径；采集器仍在远端运行。不要因为浏览器在Windows就将Linux路径转换为C盘路径。

Windows目标选择Windows，填写实际完整路径，例如：

```json
{
  "service": "example-windows-service",
  "incident_timezone": "UTC",
  "target_os": "windows",
  "languages": [],
  "runtime_checks": [["C:\\Program Files\\Python313\\python.exe", "--version"]],
  "logs": ["C:\\Logs\\example.log"],
  "log_encoding": "utf-8",
  "http": [],
  "tcp": [],
  "command_timeout": 8
}
```

JSON反斜线需双写，界面普通输入框只需单写。界面路径输入框不添加外层引号。路径包含空格时保持为argv里的一个字符串，不把整条命令拼成字符串，不用shell=True。运行时示例不代表该路径已经安装。

配置target_os与当前主机不一致时collect直接拒绝，不在错误主机上继续采集。

Windows系统信息采集使用whoami.exe、netstat.exe -ano，不调用free、df、ss。Python的PATH探测采用采集器当前sys.executable；服务实际虚拟环境仍应配置绝对路径。命令子进程额外保留Windows运行必需的SystemRoot、WINDIR、COMSPEC、PATHEXT、TEMP、TMP，不继承全部环境或凭证。

Windows命令分支拒绝直接执行.cmd/.bat，请配置实际.exe；日志或网页中的命令不得自动执行。超时/输出超限尝试taskkill /T /F并结束直接子进程；它不证明已清理所有先前分离的后代。当前不具备Windows Job Object级进程树隔离。

## 实机验收

Windows 10和11分别运行，并保留不同结果：

```powershell
py -3 -X utf8 .\tests\windows_compat.py .\windows-acceptance.json
py -3 -X utf8 .\tests\console_integration.py
```

windows_compat.py原生运行时才写windows_native_verified=true，并记录系统版本；Linux运行会明确记录模拟分支，不算Windows验收。手工继续核对：

1. 普通账号、中文用户名和包含空格的安装目录。
2. 双击启动器，浏览器打开、平台选择、导入日志、审阅、导出、重启保存。
3. Windows平台和Linux远端平台分别导出清单，路径不混淆。
4. 同一数据目录启动第二实例被拒绝；不同目录可独立使用。
5. GBK/UTF-16/带BOM JSON、缺运行时、端口占用和杀毒软件持有状态文件。
6. WorkBuddy实际导入、工具执行权限与新对话触发。
7. Windows apply/rollback在任何目标修改之前明确拒绝。

## 技术依据

- Python文件锁：https://docs.python.org/3.12/library/msvcrt.html
- Windows管道不适用selectors：https://docs.python.org/3.12/library/selectors.html
- chmod与平台差异：https://docs.python.org/3.12/library/os.html
- taskkill：https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/taskkill
