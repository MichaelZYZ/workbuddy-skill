# 可视化工作台：公开分发本地版

## 启动

Windows 10/11可双击根目录launch-console.cmd，或在PowerShell执行 `py -3 -X utf8 .\scripts\console.py`。下述python3命令用于Linux；Windows可替换为py -3。实机验收待完成，自动写入/回滚未启用。


从发行来源获取完整技能目录后，在实际目录运行。需要Python 3.10+；Linux和Windows原生适配范围见windows.md；Windows实机待测。无需pip、Node.js、ChatGPT账号或作者的托管网站。

```bash
cd /实际安装位置/diagnose-service
python3 scripts/console.py
```

用同一台机器的浏览器打开终端显示的地址，默认 `http://127.0.0.1:8765`。Ctrl+C退出。不要用root启动；不要把127.0.0.1改成公网监听。

可选参数：

```bash
python3 scripts/console.py --port 8766 --data-dir /你的私有目录/diagnose-data
```

POSIX默认数据目录为当前用户的 `~/.local/state/diagnose-service`，目录0700、状态文件0600；Windows默认%LOCALAPPDATA%\diagnose-service并继承用户目录ACL。每个用户独立安装和保管数据。通过锁防止两个进程同时写同一目录。它是本机单用户工具，不是多人SaaS或Windows常驻服务。远端生产服务器只需运行采集CLI，不需要将本地界面部署到公网。

## 非技术人员

1. 选择诊断任务，填写标题，选择关联平台和语言；不确定可选自动识别。
2. 粘贴已复核敏感内容的日志，或导入维护者提供的evidence.json。选择文件后优先分析文件；清除文件可切回粘贴文本。
3. 点击开始诊断。简明模式解释发生了什么、下一步检查什么。没有命中不代表健康。
4. 点击历史任务回看记录，导出Markdown报告交接技术人员。
5. 不自行执行不理解的服务器命令；“记录审阅”只保存说明，不会执行修复。

示例按钮仅填入带“示例”标题的日志。提交后会作为本地示例任务保存，不把它称为生产验证。

## 技术人员

1. 添加平台：部署平台、环境、主机标识、语言、运行时绝对路径、日志路径、时区、可选业务健康URL。不填写密码或密钥。
2. 导出environment.json。核对每个argv、路径和目标；将健康contains的占位文字替换为真实业务成功标记。自动语言不会生成运行时检查，需手动补充。
3. 将技能采集器和清单放在授权目标服务器。使用实际技能目录执行：

```bash
umask 077
python3 scripts/diagnose.py collect environment.json --out evidence.json
python3 scripts/diagnose.py diagnose evidence.json --out diagnosis.json
```

4. 将evidence.json导入本地工作台。主机、时间、容器与运行时由维护者核对；导入报告不具备来源签名认证。
5. 专业模式查看原始证据索引、待确认原因和专家检查门槛。按references/expert-workflow.md补充区分性证据。
6. 审阅后使用既有plan/apply机制执行授权修复，仅支持单文件的一处精确替换。升级、依赖安装等由维护者显式执行。
7. 复制assets/validation.example.json并替换所有示例值，运行：

```bash
python3 scripts/diagnose.py verify validation.json --out verification.json
```

8. 在任务详情导入verification.json。重新核对非空检查全部通过、业务断言标记和HTTP正文断言，才标记样本通过。仍不是工作台独立观测，也不代表长期生产恢复。
9. 继续观察真实请求、错误增量、延迟及正常基线。

## 记录、数据与限制

- 原始证据保存在任务中，操作事件同时输出终端JSON日志；不会将完整报告和会话Token写到运行日志。
- 事件包括平台保存、规则分析、审阅、验证导入；不是服务器实时日志流。
- 文件不超过300KB，最多200检查、200任务、100平台；最近1000条事件，旧事件会从状态中移出。长期审计需求需维护者定期归档。
- 数据写入失败会报错，不把未保存视为成功。导出/导入前均需人工复核敏感内容；正则脱敏不是保证。
- 导出与记录供本地操作者使用，不自动上传作者或其他服务。界面不执行采集、网络探测、依赖安装、远程SSH或生产修复。
- 停止程序后，按组织策略备份或清理data-dir；分享技能时不打包该目录。
- 请求限定回环Host、同源Origin与每次启动生成的会话Token；它们用于本地界面防护，不是多人登录认证。

Windows 10/11适配、启动方式、权限差异与实机验收清单见[Windows说明](windows.md)。
