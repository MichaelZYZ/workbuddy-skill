@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto try_python
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
if errorlevel 1 goto try_python
py -3 -X utf8 "%~dp0scripts\console.py"
goto finished
:try_python
where python >nul 2>nul
if errorlevel 1 goto missing
python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
if errorlevel 1 goto missing
python -X utf8 "%~dp0scripts\console.py"
goto finished
:missing
echo Python 3.10 or newer is required. Install Python and reopen this launcher.
:finished
pause
