# 异常中断与恢复手册

## 停止条件

主机/计划/备份无法确认、哈希变化、发布系统同时写文件、恢复权限未知或变更多对象时，停止自动变更。不要反复apply或修改哈希绕过保护。保留原plan、validation与实际journal。

## 状态处理

| 状态 | 下一步 |
|---|---|
| error，返回中没有journal路径 | 无法据此判断是否已经修改；按下文中断恢复流程核对目标、备份和服务 |
| verified_sample | 继续真实流量观察，不马上删备份 |
| restored | 原文件恢复且恢复探测通过，本次修复仍未完成，查看失败阶段 |
| restored_unhealthy | 文件恢复并加载但探测失败，继续按实际故障排查 |
| restore_activation_failed | 查看恢复语法/加载结果，优先人工恢复服务 |
| rollback_conflict | 外部文件变化，保留双方版本并协调负责人，不强制覆盖 |
| target/manifest changed | 重新核对后生成计划，不只修改哈希 |
| 锁错误 | 确认是否有同UID任务执行；不删除锁文件绕过活跃操作 |

显式rollback失败后可能恢复“rollback开始前”的版本，不能根据命令名推断最终内容，必须查看该次journal。

## error未返回journal路径时

恢复过程或最终保存journal本身也可能异常，此时命令可能只返回error/detail，但目标已被修改，工作目录仍有prepared记录。不能把“没有返回journal路径”当成“没有执行变更”。

先在本次workspace列出候选记录，按本次启动时间、目标文件、计划哈希和服务确认归属，不盲选最新记录，更不直接重试apply：

```bash
find "$work_dir/repair-history" -maxdepth 2 -type f -name journal.json -printf '%T@ %p\n' | sort -nr | head -10
```

找到匹配本次操作的journal后，使用下面的只读哈希检查，并核实服务实际加载状态。没有匹配记录时，使用已确认的独立备份与发布记录人工恢复，不猜测最终状态。

## prepared与进程意外终止

工具仅在开始和正常完成时保存journal，不保证逐步骤进度持久化。kill -9、掉电或恢复中再次异常时可能停在prepared，不能判断动作执行到了哪里。

以下是只读核对，先审阅journal中的目标路径，再替换示例路径：

```bash
python3 - /private/repair-history/run-实际编号/journal.json <<'PY'
import hashlib, json, pathlib, sys
j = json.loads(pathlib.Path(sys.argv[1]).read_text())
for label, name in [("target", j["target"]), ("backup", j["backup"])]:
    p = pathlib.Path(name)
    if p.is_file():
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        print(label, "sha256="+h, "matches_before="+str(h==j["before_sha256"]), "matches_after="+str(h==j["after_sha256"]))
    else:
        print(label, "missing_or_not_regular")
print("recorded_status=" + j["status"])
PY
```

目标等于before：可能未写或已恢复，仍查服务加载状态。目标等于after：可能写入，不证明检查和激活执行过。两者都不等：停止覆盖，排查外部修改。备份缺失或不等于before：不能用于恢复。

## 人工恢复检查表

1. 核对主机、最近合法发布、当前流量及授权；排除活跃修复/发布，必要时摘流。
2. 核对备份哈希与来源，确认应恢复的版本；原版本可能本来就有故障。
3. 审阅差异和权限/ACL/xattrs。before.bin只保存原文字节，不保存完整元数据，不能直接cp并假定权限相同。
4. 按可信运行手册恢复，语法通过后有限范围加载。
5. 验证真实业务、错误增量、延迟和队列，再恢复流量。
6. 记录最终哈希、实际加载版本、结果与未验证范围。

数据库、包升级和二进制替换用服务专门恢复流程，非内置单文件事务能力。

## 归档清理

观察期结束前保留plan、validation、journal和backup，由明确负责人按组织保留期清理。/tmp可能被系统清理，长期记录迁入持久私有位置并维护路径关联。原文备份不对外共享，不擅自创建定期清理任务。
