# WorkBuddy导入与使用

## 适配依据

按WorkBuddy官方技能文档（2026-10-24核对）适配目录SKILL.md、references、scripts等资源，以及description、description_zh、description_en、version、author字段。官方参考：

- https://open.workbuddy.cn/docs/skill
- https://www.workbuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market

本技能可生成WorkBuddy格式ZIP。只验证了静态包结构、解压后的清单与本地运行；尚未在真实WorkBuddy客户端完成导入验收，也未提交市场审核，不保证每个客户端版本的解析行为。

## 导入流程

1. 获取WorkBuddy专用ZIP；ZIP内只有一层diagnose-service目录，其下是SKILL.md及资源。
2. WorkBuddy左侧“专家·技能·连接器”→“技能”→“添加技能”→“上传技能”，选择ZIP。
3. 在已安装列表确认技能启用，然后新建对话使用。
4. 不要将scripts/install.py的Codex默认路径用作WorkBuddy安装路径；WorkBuddy上传功能管理其安装位置。

可输入：

> 使用diagnose-service分析以下故障日志。先只读诊断，列出已确认事实、候选原因、缺失证据和下一步检查，不修改服务器。

或：

> 使用diagnose-service帮我启动本地操作界面，先检查当前系统和Python版本。不要在公网开放端口，不要安装依赖或修改生产。

## 系统与权限

- 安装技能仅导入指令和资源，不自动安装Python、不自动连接服务器、不自动弹出界面。
- 脚本主要支持Linux、Python3.10+。Windows原生执行器不支持；macOS未完成完整执行器验证。日志推理与脚本执行范围分开说明。
- 当前机器不支持执行器时，先在对话中分析脱敏日志；需执行采集时，由维护者在授权Linux目标机运行，返回证据。使用已配置的Linux环境前核对客户端执行工具与网络能力。
- 操作界面在具备前提的本机运行python3 scripts/console.py；浏览器访问启动显示的127.0.0.1地址。不能用桌面浏览器的127.0.0.1访问另一台远端服务器的界面。
- 原生脚本和本地界面不调用外部AI服务；在WorkBuddy对话中提供的日志仍由WorkBuddy按其产品配置和条款处理。先脱敏，不能称为所有使用方式均离线。

## 打包与分发

维护者在原始技能目录执行：

```bash
python3 scripts/package_skill.py --target workbuddy --author '你的项目或作者名称' --out /你的输出目录/diagnose-service-workbuddy.zip
```

author是展示标识，正式上架时填写自己的主体名称。通用版用--target generic。打包器先校验文件白名单和哈希，仅为WorkBuddy包转换头部，并重新生成包内清单；不修改已安装技能的通用头部。界面、脚本和模板随包分发，不包含运行状态与客户报告。

可导入测试不等于公开市场已上架。公开上架仍需维护者确定许可条款、主体、发布渠道，并按平台流程提交。不要代签平台条款或猜测作者法律身份。
