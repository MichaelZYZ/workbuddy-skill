# 验证覆盖与维护验收

## 已完成验证

tests/last-validation.json包含当次时间、运行时和脚本SHA256。基准为16组通过、0失败、0跳过，覆盖真实TCP拒绝/成功、HTTP正文、证据缺失、脱敏、超时/输出限制、阶段失败停止、修复与回滚/冲突保护、拒绝仅状态码验收、六个语言修复场景、CLI采集/诊断及日志回放。

| 语言 | 当次运行时 | 真实场景 |
|---|---|---|
| PHP | 8.3.6 CLI | require缺文件、implode参数顺序 |
| Python | 3.12.14 | 模块导入失败 |
| Node.js | 24.19.0 | 模块路径失败 |
| Java | OpenJDK 17.0.20 | 类加载失败 |
| Go | 1.22.2 | nil指针panic |

这是本机隔离fixture：复现报错，修改，执行语言检查及程序，再做本地HTTP正文断言。不是PHP补丁安全认证、生产框架兼容或性能压测。历史数据库日志回放不代表制造或修复真实数据库故障。

## 未覆盖范围

真实FPM排空、PM2/Docker/K8s生命周期、真实数据库/Redis/ES、跨机锁、生产大流量、断电、各种ACL/SELinux/挂载、全部脱敏、Windows/macOS、认证接口及各框架未完整覆盖。对应能力需要预发补测，不能用基准结果替代。

## 复测

在可信隔离环境、技能根目录执行：

```bash
python3 tests/integration.py /tmp/diagnose-validation.json
```

测试创建临时文件、监听127.0.0.1并执行可信样例，不连接生产。Python必需，其他语言按PATH发现，Java需含编译器模块，Go需本机工具链；缺失会skipped，不能算通过。检查failed、skipped及具体场景，而非只看总通过数。

核对结果对应的实现：

```bash
python3 - <<'PY'
import hashlib, json, pathlib
r=json.loads(pathlib.Path("tests/last-validation.json").read_text())
h=hashlib.sha256(pathlib.Path("scripts/diagnose.py").read_bytes()).hexdigest()
print("implementation_matches_recorded_result="+str(h==r["implementation_sha256"]))
print(r["counts"])
PY
```

文档变更核对链接、JSON和CLI即可；脚本/规则/修复逻辑变化需相关测试及完整回归，并更新结果与哈希。

## 新规则与新语言验收

1. 保留脱敏失败样本、完整栈、运行时与期望；原始证据不预置根因。
2. 规则只输出观测、候选原因与区分性检查，不把关键词当根因。
3. 加负例：checkpoint不能误判磁盘故障，单次TCP成功不能声明持续恢复。
4. 修复测试正常/失败输入、语法失败、业务失败、回滚和外部文件变化。
5. 区分真实运行、历史回放与静态分析；运行时缺失明确skipped。
6. 新诊断规则不等于新增自动修复能力；多文件和依赖管理需另行设计。
7. 独立复核后预发试用，确认后更新技能及验证记录。

## 1.1 验证增量

本次隔离复测17组通过、0失败、0跳过，含PHP、Python、Node.js、Java、Go真实运行时。新增历史Connection refused与当前TCP成功共存时仍保持根因未确认，并核对证据来源字段、缺口和变更门槛。结果见tests/last-validation.json。可视化应用另有12项分析/导入断言与浏览器人工操作验证；不代表用户生产验证或所有平台API对接。

## 1.2 公开分发适配验证

新增独立本地界面，不依赖作者账号和网站。tests/console_integration.py提供24项真实回环HTTP与状态保存检查，覆盖同源/会话Token/Host校验、注入格式、平台清单导出、诊断、审阅、验证导入、脱敏、私有权限和重启保存；tests/install_integration.py提供5项离线安装、白名单与篡改/覆盖拒绝检查。独立新用户试验通过安装及Python导入诊断，并复查了运行数据不会随发行白名单复制。测试容器以root运行，未据此宣称普通用户、Windows或所有客户端已全面验证。本次本地界面未完成浏览器视觉验收；HTTP集成检查与JS语法检查不能替代完整浏览器验收。
