# 多语言诊断手册

| 语言 | 首要证据 | 只读检查 | 修复与验收 |
|---|---|---|---|
| PHP | CLI/FPM真实版本、php.ini、扫描目录、扩展ABI、FPM慢日志及队列 | 指定绝对路径 `php -v`, `php --ini`, `php -m`, `php --ri redis`; FPM `-t`; 源码 `php -l file.php` | 缺so先核对路径和实际文件；用目标phpize重编译；CLI成功后仍需FPM真实请求。OOM分析数据规模与内存预算，不盲目取消限制。 |
| Python | 服务ExecStart、venv解释器、工作目录、依赖锁、完整traceback | 指定venv的 `python --version`, `python -m pip check`, `python -m pip show 包名` | 不用全局pip修复venv；在隔离环境按锁文件重建，切换并验证真实入口。语法检查可用compile()只编译不执行。 |
| Node.js | Node版本、CWD、package.json/锁文件、完整堆栈、PM2/容器状态 | `node --version`, `node --check file.js`，阅读锁文件和进程配置 | 区分缺包、相对路径、构建缺失、ESM/CJS。不要自动npm install最新版。npm ci会修改目录并可能运行安装脚本，仅在明确授权的隔离构建目录。 |
| Java | java路径、JVM参数、完整Caused by、jar版本、GC和容器限制 | `java -version`, 授权时jcmd特定PID的VM.flags/GC.heap_info | 区分heap、Metaspace、direct/native内存。jcmd/JFR/heap dump可能暂停或消耗磁盘，先限定时长和空间，heap dump含敏感数据。 |
| Go | go版本、构建提交、完整goroutine栈、模块锁 | `go version`, `go version -m binary`; 在工作副本验证构建 | nil dereference与并发map问题需源码定位；race检测仅预发，可能昂贵。go test/生成器可能执行仓库代码，需要信任项目。 |

## 语言无关的修复模板

- 明确触发请求及预期输出；保留故障样本，修复前复现。
- 先做最小修复；保留输入输出契约。比如PHP交换implode参数不应顺手重构业务。
- 依赖和配置修复同时验证版本、加载来源与功能，不能只对比模块名称。
- 兼容升级检查所有过渡版本的迁移说明；CVE只依赖可信公告和补丁记录，不通过OOM回调测试声称漏洞安全。
- 多进程/多实例下，按部署实例逐个切换；共享缓存、Session和数据库变更需兼容并存版本。
- 生产查询限时、限量；不记录认证头、请求内容及任意完整环境变量。
