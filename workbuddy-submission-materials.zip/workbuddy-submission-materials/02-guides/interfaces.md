# 参数、状态与已知限制

## 命令契约

所有输入为JSON；命令的具体示例见operator-guide.md，执行前在技能目录运行对应子命令--help。

| 命令 | 参数 | 行为 |
|---|---|---|
| collect | input，可选--out | 读取环境清单并采集 |
| diagnose | input，可选--out | 按错误特征对证据分流 |
| verify | input，可选--out | 仅HTTP/TCP，不执行preflight/activate |
| plan | --service --root --target --before --after --validation --out | 生成单文件精确替换计划，不改目标 |
| apply | plan --workspace | 备份、修改、语法检查、激活、验证或恢复 |
| rollback | plan --workspace --journal | 使用原计划及实际journal恢复并验证 |

0表示处理按预期完成；2表示参数/执行异常、verify失败或修复未达预期。collect/diagnose返回0不代表目标健康。--out覆盖同名文件；未指定输出到stdout。参数解析错误可能是文本，不保证所有错误都是JSON。

## 环境清单

| 字段 | 类型/默认 | 说明 |
|---|---|---|
| service | 字符串，必填 | 服务标签，不自动选择主机 |
| incident_timezone | 字符串/unknown | 原故障时区标签，不自动转换每条日志 |
| languages | 数组/[] | php/python/node/java/go的PATH探测；未知名称目前忽略，审阅时排除拼写错误 |
| runtime_checks | argv数组的数组/[] | 无shell展开，可信操作者审阅后执行，采集阶段只配置只读命令 |
| logs | 路径数组/[] | 每文件最后最多64KiB，忽略截断首行，可能遗漏故障时间窗 |
| tcp | 对象数组/[] | 每项host/port；collect只采样一次 |
| http | 对象数组/[] | 每项url，可选status/contains/timeout |
| command_timeout | 数字/8 | runtime_checks每条超时，截为0.1至60秒 |

固定uptime/free/df/ss和PATH版本检查使用默认8秒。单条命令输出最多32KiB，达到上限会终止并记录output_limit；超时尝试终止进程组，不用于启动常驻服务。

## 验证清单

| 字段 | 默认/约束 | 说明 |
|---|---|---|
| preflight | argv数组的数组 | apply至少一条；替换文件后、激活前执行 |
| activate | [] | 顺序执行，失败停止后续命令 |
| http | [] | apply至少一个含非空contains的HTTP探测 |
| tcp | [] | 附加连接检查，不能替代业务断言 |
| samples | 3，限制1至10 | 每轮执行全部探测 |
| interval | 0.2，限制0至2秒 | 每轮探测后的等待，不是固定采样频率 |

preflight/activate每条固定15秒，暂不可配置。TCP默认每个连接尝试2秒，但DNS与多地址尝试不保证总耗时2秒。HTTP默认3秒、上限30秒，需正数；属于socket超时，不是脚本总截止时间。

HTTP只支持GET，无自定义认证头、Host、请求体、代理或重定向跟随；HTTPS使用默认CA校验，不支持跳过证书校验。需要认证/Host/POST时使用另行审阅的外部验证流程，不用无关公共接口冒充。

contains只匹配前32KiB正文的字面量子串，正文不写入结果。避免用ready匹配not_ready；采用明确状态片段并核对空格和大小写。非2xx预期状态仅能在无正文断言时按状态匹配；apply不适合必须验证非2xx正文的服务。

## 输出契约

- evidence包含schema_version、tool_version、service、collected_at、incident_timezone、checks。
- command结果包含kind/check/observed_at，可含status、exit_code、duration_ms、output。缺程序时部分字段不存在。
- log包含historical=true、path、mtime、size_bytes和脱敏output；历史样本不代表新发生。
- TCP成功时含resolved_ips和实际peer；失败时不保证保留解析列表。
- findings的evidence是checks零起始索引，confidence是标签不是概率。unknown/next说明证据缺口与检查方向。
- evidence_gaps仅覆盖部分缺失/超时状态，DNS或一般failed仍需直接看checks。
- plan保存原文、前后哈希及验证清单哈希；不是签名文件，哈希不是鉴权机制。
- apply返回journal路径/status/可能的verification和error；完整阶段结果在journal。
- verify的passed要求非空探测且所有采样成功。business_assertion_present只表示是否配置正文断言。

结果可缺省，不要把缺字段当0或成功。当前没有独立JSON Schema校验器，按本契约审阅输入类型。

## 已知边界

没有自动日志时间窗/轮转追踪、告警订阅、网段发现、多机协调、自动包安装或数据库修复。规则匹配不是全框架根因引擎，也不是CVE安全认证。文件锁不覆盖外部写入，原子替换不保证断电事务。日志脱敏、特殊文件元数据、所有系统版本均无完整覆盖。

## 1.1 向后兼容字段

collect增加host（采集器所在主机）与collector_pid。它不是远端身份认证。diagnose保留原字段，新增expert_review（根因/变更就绪均默认false、缺失上下文、成功探测索引、验收门槛）以及每条finding的evidence_scope和decision（问题、下一项检查、验收与停止条件）。这些字段不执行命令，不构成生产变更授权。tcp_refused_log识别历史日志拒绝连接，与tcp_refused实时探测分开。
