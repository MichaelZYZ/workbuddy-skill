# 多语言故障诊断与修复验证：操作指南

## 目录

1. 适用范围与前提
2. 对话使用：不需要自己写命令
3. 首次接入服务器
4. 手动采集与诊断
5. 配置验证清单
6. 创建并审阅修复计划
7. 执行修复与处理失败
8. 显式回滚
9. 五种语言如何配置
10. 常见问题与交接清单

补充文档：[接入与权限](deployment.md)、[参数与限制](interfaces.md)、[异常恢复](recovery.md)、[验证范围](validation.md)。交接模板位于技能根目录的 `assets/incident-report-template.md`。

公开分发、首次安装及升级见[发行说明](release-guide.md)。不想编写命令的使用者可先按[本地界面指南](console-guide.md)启动随技能提供的操作界面。

## 1. 适用范围与前提

主要面向Linux，执行脚本需要Python 3.10+。技能支持PHP/FPM、Python、Node.js、Java、Go的错误特征分流，以及Nginx、TCP、数据库日志分析。规则命中不是根因确认。

Skill由AI指导流程，`scripts/diagnose.py`负责确定性的采集、检测与单文件修复事务。Skill不是常驻监控系统，不会自行获得SSH权限、定时运行、自动安装依赖或自动修复所有故障。

- 需要本机执行时，将技能文件放在目标服务器上，或通过已有授权连接在目标机执行。
- 仅有聊天中的日志时，可先分析，不声称完成主机检查或生产验证。
- Python采集脚本不要求同时安装五种语言；仅配置与目标相关的语言。
- CLI测试与FPM、容器、虚拟环境的实际运行状态分别确认。
- 文件备份、锁和原子替换依赖Unix机制，Windows原生执行器未适配。
- 自动修复只支持现存普通文件的一处精确替换；多文件变更、升级、包安装和数据库变更需另行实施。

## 2. 对话使用：不需要自己写命令

在支持本技能的AI客户端选择技能，或输入：

> 使用 $diagnose-service 排查Ubuntu生产服务器上的PHP接口502。PHP目录/opt/php，Nginx日志/data/wwwlogs/error_nginx.log，发生在UTC时间06:05。先只读诊断，不修改配置。

也可以只上传错误日志并说明：

> 使用 $diagnose-service 分析这些日志，列出已确认事实、候选原因、缺失证据和下一步检查。

流程：

1. AI确认目标与故障时间，复用已有上下文，不重复询问已知信息。
2. 有授权连接则在目标环境采集；无连接则给出有限检查命令，由操作者运行后回传。
3. AI输出有证据引用的诊断及最小修复计划。
4. 修复在会话授权范围内执行；超出授权时先展示具体计划和影响，再确认。
5. 检查语法、服务和业务结果；失败按计划回滚。
6. 返回修复记录与观察建议。没有真实请求或足够观察时明确标注。

修复请求示例：

> 按已展示的计划修复这个配置，先备份；语法检查或业务验证失败就恢复，并给我结果和回滚记录。

不要把服务器密码、私钥、数据库口令直接粘贴到对话或环境JSON。使用现有凭证管理和授权连接。

## 3. 首次接入服务器

### 准备工作目录

技能在不同客户端的安装位置不同。将下面的目录替换为实际技能目录，不要默认它在生产服务器上已经存在：

```bash
cd /实际位置/diagnose-service
python3 --version
python3 scripts/diagnose.py --help

umask 077
work_dir=$(mktemp -d /tmp/diagnose-session.XXXXXX)
cp assets/environment.example.json "$work_dir/environment.json"
echo "$work_dir"
```

后续命令在同一终端、同一技能目录执行；换终端时重新设置 `work_dir` 为上面返回的目录。示例使用/tmp作为本次工作目录，结果需要长期保存时迁移到组织规定的私有位置。

### 编辑环境清单

```json
{
  "service": "example-service",
  "incident_timezone": "UTC",
  "languages": [],
  "runtime_checks": [
    ["/opt/php/bin/php", "-v"],
    ["/opt/php/bin/php", "--ini"],
    ["/opt/php/bin/php", "-m"]
  ],
  "logs": ["/opt/php/var/log/slow.log"],
  "tcp": [],
  "http": [],
  "command_timeout": 8
}
```

字段说明：

| 字段 | 含义与注意事项 |
|---|---|
| service | 自定义服务名称；结果用于关联本次检查，不会自动选择主机 |
| incident_timezone | 故障原始时区；采样时间仍记录UTC。不会自动解析和转换所有历史日志时间 |
| languages | 可选php/python/node/java/go。按PATH探测CLI；自定义部署优先使用runtime_checks绝对路径 |
| runtime_checks | 可信操作者审阅过的argv数组。采集阶段仅配置只读命令；工具不判断命令是否有副作用 |
| logs | 明确指定的日志路径；只读文件尾部，最多64KiB；不代表整个故障时间窗 |
| tcp | 明确目标，如 `{"host":"127.0.0.1","port":27100}`；会实际发起连接 |
| http | 明确GET地址及断言；仅使用无副作用且已授权的检查接口 |
| command_timeout | runtime_checks每条命令的超时秒数，最多60秒 |

采集器还会尝试uptime、free、df和ss。未安装工具或权限不足会作为证据缺口记录，不要求为此使用root。不要把检查结果归到另一台主机。

## 4. 手动采集与诊断

```bash
python3 scripts/diagnose.py collect "$work_dir/environment.json" \
  --out "$work_dir/evidence.json"

python3 scripts/diagnose.py diagnose "$work_dir/evidence.json" \
  --out "$work_dir/diagnosis.json"

python3 -m json.tool "$work_dir/diagnosis.json"
```

`--out`会创建或覆盖指定JSON文件，默认不会将完整结果打印到终端。证据包含脱敏后的有限输出、采样时间、命令结果和状态。

诊断结果重点阅读：

- `findings[].rule`：匹配的错误类别；可能同时命中多类。
- `findings[].evidence`：引用evidence中checks的零起始索引。
- `unknown`和`next`：未确认事项与下一项检查。
- `evidence_gaps`：不可用、无权限、超时或截断的证据索引。

`diagnose`不是完整根因引擎，规则没有命中也不等于健康。仍需AI和操作者结合业务请求、代码和部署信息判断。

## 5. 配置验证清单

将 `assets/validation.example.json` 复制为工作副本后编辑：

```bash
cp assets/validation.example.json "$work_dir/validation.json"
```

模板内所有路径、服务和地址均是示例，使用前必须替换。结构如下：

```json
{
  "preflight": [["/opt/nginx/sbin/nginx", "-t"]],
  "activate": [["/opt/nginx/sbin/nginx", "-s", "reload"]],
  "http": [{
    "url": "http://127.0.0.1:8080/health",
    "status": 200,
    "contains": "\"status\":\"ready\""
  }],
  "samples": 3,
  "interval": 0.5
}
```

- preflight：替换文件后、激活前执行的语法或配置检查。不能填无意义的永远成功命令。
- activate：按授权执行的加载命令。每条命令成功后才执行下一条；失败停止。
- http：GET、不跟随重定向、默认不用环境代理。`contains`是字面量子串，需要与真实业务响应格式一致；不是JSON字段解析器。
- samples：1到10次采样；interval：0到2秒的间隔，默认0.2秒。样本不足不代表长期恢复。

先独立验证当前业务：

```bash
python3 scripts/diagnose.py verify "$work_dir/validation.json"
```

**独立verify只执行HTTP/TCP，不执行preflight或activate。**它可以在修复前返回失败，供建立基线。apply必须提供preflight以及至少一个非空HTTP正文断言，避免仅凭200就认定业务通过。

## 6. 创建并审阅修复计划

下面只是参数格式示例：必须先确认真实根因，并将文件与替换值换成已确认的变更。验证清单要匹配被修改服务，不能用无关健康接口验收。

```bash
python3 scripts/diagnose.py plan \
  --service demo \
  --root /srv/demo \
  --target /srv/demo/config.json \
  --before '"port": 9001' \
  --after '"port": 9000' \
  --validation "$work_dir/validation.json" \
  --out "$work_dir/plan.json"

python3 -m json.tool "$work_dir/plan.json"
```

plan只读取目标，不修改它。替换内容必须恰好匹配一次。目标必须是root内已存在的普通文件，符号链接和硬链接会拒绝。

审阅：目标环境、修改原因、前后文本、影响、语法检查、激活命令、业务断言和回滚条件。计划内原文可能含秘密，不直接公开。创建计划后更改目标或验证清单，会使哈希检查失败；应重新核对并生成计划，不能强行绕过。

## 7. 执行修复与处理失败

在授权范围内：

```bash
python3 scripts/diagnose.py apply "$work_dir/plan.json" \
  --workspace "$work_dir/repair-history"
```

脚本返回journal绝对路径。复制该路径供交接与回滚使用；不要把示例中的run-XXX当真实路径。

| 状态 | 操作 |
|---|---|
| verified_sample | 本次修复及清单短时探测通过；继续观察真实请求、错误增量、延迟和队列 |
| restored | 修复失败，已恢复原文件，恢复检查通过；查看error及journal找出失败环节 |
| restored_unhealthy | 已恢复原文件并加载，但恢复后的探测仍失败；不能宣称业务恢复 |
| restore_activation_failed | 恢复文件后语法或加载失败；优先按备份和服务日志人工恢复 |
| rollback_conflict | 文件被其他操作者修改，工具未强行覆盖；协调发布负责人处理 |
| error | 可能是前置失败，也可能在修改后的恢复或日志保存时失败；查看detail，按恢复手册核对workspace、文件哈希和服务，不能直接重试 |

返回码：正常命令为0；verify失败、apply/rollback未完成预期结果或异常为2。collect/diagnose返回0只代表处理完成，不代表目标服务健康。

备份目录0700，JSON与原文备份0600。不要删除正在使用的repair-history；备份不自动过期。进程被SIGKILL或主机掉电时不保证自动恢复，检查prepared状态journal和备份。

## 8. 显式回滚

将下面journal替换为第7步实际返回的路径：

```bash
python3 scripts/diagnose.py rollback "$work_dir/plan.json" \
  --workspace "$work_dir/repair-history" \
  --journal "$work_dir/repair-history/run-实际编号/journal.json"
```

目标必须仍等于该计划修复后的内容，备份、计划、验证清单必须可用且匹配。否则工具拒绝覆盖。显式回滚仍执行语法检查、激活和业务验证；原故障配置本身不健康时，不能保证回滚后业务通过。

## 9. 五种语言如何配置

| 场景 | runtime_checks示例 | 日志/补充检查 |
|---|---|---|
| PHP | `["/opt/php/bin/php","-v"]`、`--ini`、`-m` | FPM慢日志、池状态、实际FPM版本、对应扩展ABI |
| Python | `["/srv/app/.venv/bin/python","--version"]` | 完整traceback、服务ExecStart、venv与工作目录 |
| Node.js | `["/usr/bin/node","--version"]`，按实际路径改 | PM2应用日志、锁文件、CWD和构建产物 |
| Java | `["/usr/bin/java","-version"]` | 完整Caused by、JVM参数、容器限制、现有GC日志 |
| Go | `["/usr/local/go/bin/go","version"]`，按实际路径改 | panic/goroutine栈、构建版本、模块信息 |

依赖安装、执行项目测试和编译可能有副作用；不要因为命令叫test就默认安全。实际连接数据库使用明确的只读账号和限量查询。详见languages.md和infrastructure.md。

## 10. 常见问题与交接清单

- **找不到脚本**：先cd到实际技能目录；技能安装在AI环境不意味着服务器已经有同一目录。
- **找不到Python或工具**：确认Python版本与PATH；不要把缺工具当服务停止。
- **端口成功仍报错**：检查是否同主机、地址族、进程和时间点，针对间歇故障做有界同步采样。
- **没有发现问题**：可能未覆盖故障时间窗或特征不在规则中，不代表安全或健康。
- **日志泄露风险**：脱敏是尽力而为；分享前复核，不分享原始配置备份和凭证。
- **是否能直接改生产**：只有在已授权范围内，且计划、备份、检查、回滚路径明确时；技能不会自动获得权限。

每次交接保留：目标主机/环境、原始故障时间及其时区、evidence、diagnosis、经审阅的plan、validation、实际journal路径、变更结果、观察指标和未验证事项。

在隔离环境复查实现：

```bash
python3 tests/integration.py /tmp/diagnose-validation.json
```

真实语言测试要求对应运行时；未安装会报告skipped，不能计为通过。已有验证结果见tests/last-validation.json，代表当次隔离环境，不代表你的生产已通过。
